const mobileSearchBtn = document.querySelector('.mobile-search-btn')
const mobileSearchInput = document.querySelector('.mobile-search-input')
mobileSearchBtn.addEventListener('click', () => {
  mobileSearchInput.classList.toggle('active')
  mobileSearchInput.focus()
})


let swiper = new Swiper(".heroSwiper", {
  slidesPerView: 1,
  centeredSlides: true,
  loop: true,
  spaceBetween: 30,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  navigation: {
    nextEl: ".hero-next",
    prevEl: ".hero-prev",
  },
  breakpoints: {
    768: {
      slidesPerView: "auto",
    },
  },
});